local aguanta = false;
local boom = true;
function onCreate()
	makeLuaSprite('fondo','12', -655, -400);
	makeLuaSprite('texto1','we', 120, -150);
	makeLuaSprite('texto2','cock', 120, -180);
	makeLuaSprite('texto3','dick', 120, -180);
	makeLuaSprite('texto4','balling', 120, -150);

	
	setObjectCamera('texto1', 'other');
	setObjectCamera('texto2', 'other');
	setObjectCamera('texto3', 'other');
	setObjectCamera('texto4', 'other');
	
	makeAnimatedLuaSprite('wey', 'doce', -222, -10);
	addAnimationByPrefix('wey', 'mover', 'doce idle', 48, false);
	
	scaleObject('wey', 8, 8);
	scaleObject('fondo', 8, 7);
	
	addLuaSprite('texto1', true);
	addLuaSprite('texto2', true);
	addLuaSprite('texto3', true);
	addLuaSprite('texto4', true);
	addLuaSprite('fondo', false);
	
	setProperty('cameraSpeed', 3);
	setProperty('camHUD.alpha', 0);
	setProperty('texto1.alpha', 0);
	setProperty('texto2.alpha', 0);
	setProperty('texto3.alpha', 0);
	setProperty('texto4.alpha', 0);
end

function onCreatePost()
	for i = 0, getProperty('opponentStrums.length')-1 do
		setProperty('gf.visible', false);
	end
end

function onCountdownTick(counter)
	if counter == 0 then
		doTweenZoom('zoom0', 'camGame', 0.655, 0.15, 'linear');
		setProperty('camHUD.alpha', 0);
	elseif counter == 1 then
		doTweenZoom('zoom1', 'camGame', 0.68, 0.15, 'linear');
		setProperty('camHUD.alpha', 0.3);
	elseif counter == 2 then
		doTweenZoom('zoom2', 'camGame', 0.7, 0.15, 'linear');
		setProperty('camHUD.alpha', 0.6);
	elseif counter == 3 then
		doTweenZoom('zoom3', 'camGame', 0.72, 0.15, 'linear');
		setProperty('camHUD.alpha', 1);
	end
end

function onUpdate(elapsed)
	if mustHitSection == true and not aguanta then
		doTweenZoom('zoom', 'camGame', 1, 0.1);
	elseif mustHitSection == false and not aguanta then
		doTweenZoom('zoom', 'camGame', 0.65, 0.1);
	end
	objectPlayAnimation('wey', 'mover');
end

function onEvent(name, value1, value2)
	if value1 == '' then
		--chupamela
	else
		value1 = tonumber(value1);
	end
	
	if name == 'boom' then
		playSound('vineBoom', 1);
		boom = false;
	end

	if name == 'poner' and value1 == 1 then
		addLuaSprite('wey', true);
		setProperty('dad.visible', false);
	elseif name == 'poner' and value1 == 2 then
		removeLuaSprite('wey', false);
		setProperty('dad.visible', true);
	elseif name == 'poner' and value1 == '' then
		addLuaSprite('wey', true);
		setProperty('dad.visible', false);
	end
	
	if name == 'cock' then
		runTimer('texto1', 0);
		aguanta = true;
	end
end

function onTimerCompleted(tag, loops, loopsLeft)
	if tag == 'texto1' then
		
		cameraSetTarget('dad');
		doTweenZoom('zoom', 'camGame', 0.8, 0.1);
		setProperty('texto1.alpha', 1);
		doTweenAlpha('we', 'texto1', 0, 0.5, 'easeOut');
		playSound('we', 2);
		runTimer('texto2', 0.5);
		
	elseif tag == 'texto2' then
		
		cameraSetTarget('dad');
		doTweenZoom('zoom', 'camGame', 1.2, 0.1);
		setProperty('texto2.alpha', 1);
		doTweenAlpha('we', 'texto2', 0, 0.5, 'easeOut');
		playSound('cock', 2);
		runTimer('texto3', 0.5);
		
	elseif tag == 'texto3' then
		
		cameraSetTarget('dad');
		doTweenZoom('zoom', 'camGame', 1.5, 0.1);
		setProperty('texto3.alpha', 1);
		doTweenAlpha('we', 'texto3', 0, 0.5, 'easeOut');
		playSound('dick', 2);
		runTimer('texto4', 0.5);
		
	elseif tag == 'texto4' then
		
		cameraSetTarget('dad');
		doTweenZoom('zoom', 'camGame', 1.9, 0.1);
		setProperty('texto4.alpha', 1);
		doTweenAlpha('we', 'texto4', 0, 0.5, 'easeOut');
		playSound('balling', 2);
		runTimer('terminar', 1.7);
		
	elseif tag == 'terminar' then
		removeLuaSprite('texto1', true);
		removeLuaSprite('texto2', true);
		removeLuaSprite('texto3', true);
		removeLuaSprite('texto4', true);
		addLuaSprite('wey', true);
		setProperty('dad.visible', false);
		aguanta = false;
	end
end

function onBeatHit()
	if getProperty('dad.visible') == false then
		setProperty('camGame.zoom', 1);
	end
end

function opponentNoteHit(id, direction, noteType, isSustainNote)
	if boom then
		playSound('vineBoom', 1);
	end
end